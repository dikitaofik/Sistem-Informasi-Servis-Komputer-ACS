	</div><!-- /#wrapper -->
	
	<!-- footer-bottom -->
	<div class="navbar navbar-inverse navbar-fixed-bottom footer-bottom">
		<div class="container text-center">
			<p class="text-center" style="color: #D1C4E9; margin: 0 0 5px; padding: 0"><small>Ajat Komputer Sistem</p>
		</div>
	</div><!-- /.footer-bottom -->

	<!-- Bootstrap Core JavaScript -->
	<script src="libs/bootstrap/dist/js/bootstrap.min.js"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="libs/metisMenu/dist/metisMenu.min.js"></script>
	<!-- DataTables JavaScript -->
    <script src="libs/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="libs/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
	<!-- jTebilang JavaScript -->
	<script src="libs/jTerbilang/jTerbilang.js"></script>
	<!-- Custom Theme JavaScript -->
	<script src="dist/js/sb-admin-2.js"></script>

</body>
</html>